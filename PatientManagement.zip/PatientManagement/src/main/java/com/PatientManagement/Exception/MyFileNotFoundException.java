package com.PatientManagement.Exception;

public class MyFileNotFoundException extends Exception {
    public MyFileNotFoundException(String msg) {
        super(msg);
    }
}
